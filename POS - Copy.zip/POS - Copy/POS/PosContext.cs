﻿using Microsoft.EntityFrameworkCore;
using System.Configuration;

namespace POS
{
    public class PosContext : DbContext
    {
        public PosContext()
        {
            string a = "Fired";
        }
        //protected class means no body can access from outside the class (e.g f12 dbcontext see protected ctor)
        //make the datacontext class aware of the classes you want it to track
        //Table names are taken from what DbSet is being defined to be tracked in the DbContext class (e.g Supermarkets same name as table in ssms)
        public DbSet<Terminal> Terminals { get; set; }
        public DbSet<Supermarket> Supermarkets { get; set; }
        public DbSet<Catalog> Catalogs { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Sale> Sales { get; set; }
        public DbSet<SaleLineItem> SaleLineItems { get; set; }


        // Method inherited from DbContext.
        // Doesn't need to be explicitly called as it will be fired by EF when connection is required
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlServer("Data Source=localhost;Initial Catalog=PosDb;Integrated Security=True");
        }
    }
}
