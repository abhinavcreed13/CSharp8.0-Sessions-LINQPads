﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POS
{
    public class SaleLineItem //class
    {
        private SaleLineItem()
        {

        }
        public SaleLineItem(Product product, int quantity) //ctor
        {
            Product = product;
            Quantity = quantity;
        }

        public int Id { get; set; } //prop
        public decimal Total { get => Product.Price * Quantity; } //prop
        public int  ProductId { get; set; }

        public Product Product { get; private set; } //prop
        public int Quantity { get; private set; } //prop


    }


}
