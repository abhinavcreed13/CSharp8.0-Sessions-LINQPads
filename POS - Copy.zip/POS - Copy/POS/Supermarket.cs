﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace POS
{
    public class Supermarket
    {
        // null constructor to allow DbContext to track supermarket class

        // why instantiate list of terminals and catalogs ?
        //private Supermarket() //constructor
        //{
        //    Terminals = new List<Terminal>();
        //    Catalogs = new List<Catalog>();
        //}

        // overloaded constructor to make Supermarket objects in RAM
        public Supermarket(string name)
        {
            Name = name;
        }
        public int Id { get; set; } //prop
        public string Name { get; set; } //prop


        public List<Catalog> Catalogs { get; set; } //prop
        public Catalog AddCatalog(string name)
        {
            var c = new Catalog(name);
            Catalogs.Add(c);
            return c;
        }

        public Catalog GetCatalog(string name)
        {
            return Catalogs.FirstOrDefault(c => c.Name.Equals(name));
        }

        //If a class has a collection of items/has the initialising data for them 
        //It should be the creator of them (supermarket has a collection of terminals)
        // navigation property
        public List<Terminal> Terminals { get; set; } //prop
        public Terminal AddTerminal() //method to add a terminal to the list of terminals related to a supermarket
        {
            var t = new Terminal();
            Terminals.Add(t);
            return t;
        }


    }
}
