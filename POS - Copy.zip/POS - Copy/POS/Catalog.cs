﻿using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

namespace POS
{
    public class Catalog
    {
        //The empty catalog constructor dataContext will track
        private Catalog() //constructor
        {
            Products = new List<Product>();
        }

        // "this()"  means chaining constructors to call the 
        // empty constructor above (this() = constructor with () = Catalog())
        // otherwise products are never instantiated as a list
        public Catalog(string name)
            :this()
        {
            Name = name;
        }
        public int Id { get; set; } //prop 
        public int SuperMarketId { get; set; } //prop
        public string Name { get; set; } //prop
        // navigation properties
        public List<Product> Products { get; set; } //prop
        public Supermarket Supermarket { get; set; } //prop


        public Product AddProduct(string name, decimal price) //method
        {
            var p = new Product(name, price);
            Products.Add(p); 
            return p;
        }
        public Product GetProduct(int id) //method
        {
            return Products.FirstOrDefault(p => p.Id == id);
        }   
        public Product GetProduct(string name) //method
        {
            return Products.FirstOrDefault(p => p.Name.Equals(name));
        }
    }
}