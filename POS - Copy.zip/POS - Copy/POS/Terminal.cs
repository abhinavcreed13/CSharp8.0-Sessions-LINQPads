﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace POS
{
    public class Terminal
    {

        public Terminal() //constructor
        { 
            Sales = new List<Sale>();
        }

        public int Id { get; set; }

        public int SupermarketId { get; set; }
        
        // Navigation properties
        private List<Sale> Sales { get; set; }
        public decimal AverageSaleTotal { get => Sales.Average(s => s.Total); }

        public Sale CreateSale()
        {
            var s = new Sale();
            Sales.Add(s); 
            return s;
        }


    }
}
