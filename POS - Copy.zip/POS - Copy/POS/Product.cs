﻿using System.Collections.Generic;

namespace POS
{
    public class Product //class
    {

        private Product() { } //private constructor so datacontext can track this class
        public int Id { get; set; } //prop
        public int CatalogId { get; set; } //prop
        public Catalog Catalog { get; set; } //prop
        public string Name { get; set; } //prop
        public decimal Price { get; set; } //prop

        public Product(string name, decimal price) //method
        {
            this.Name = name;
            this.Price = price;
        }
    }
}