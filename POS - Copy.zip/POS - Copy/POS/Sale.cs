﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace POS
{
    public class Sale
    {
        public Sale() //constructor
        {
            SaleLineItems = new List<SaleLineItem>();
            DateTime = DateTime.Now;
        }

        public int Id { get; set; } //prop
        public int TerminalId { get; set; } //prop
        public Terminal Terminals { get; set; } //prop
        public DateTime DateTime { get; private set; } //prop
        public List<SaleLineItem> SaleLineItems { get; set; } //prop
        public decimal Total { get => SaleLineItems.Sum(sli => sli.Total); } //prop

        public SaleLineItem AddItem(Product product, int quantity)
        {
            if (quantity < 1)
            {
                throw new Exception("Quantity must be greater than zero");
            }
            var sli = new SaleLineItem(product, quantity);
            SaleLineItems.Add(sli);
            return sli;
        }
    }
}
