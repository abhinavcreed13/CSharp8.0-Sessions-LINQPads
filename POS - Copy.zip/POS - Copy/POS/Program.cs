﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Configuration;
using System.Data.Common;
using System.Linq;



// Setting up EF
//----------------------------------------------------------------------------------------------------------------------------------------------------------------

//0. Make sure models are created and available for use in DbContext

//1. download nuget packages Microsoft.EntityFrameworkCore.SqlServer / Install-Package Microsoft.EntityFrameworkCore.Tools
// (does all the work for connecting to the database and reading
// records from the database and turning them into objects)

//2. get connection string (View-> server explorer, get an existing databases connection string then rename
// the database catalog = {new database name})

//4. Add a DataContext class that inherits from DbContext used to
// track the sync between app and database (clean = fully synced , dirty = not-saved in database)

//5. In order to create tables in SQL call "Add-Migration {choose migration iteration name}" in package-manager-console (View-> other windows)
// to update the app with recent migrations available for committing to the db

//6. use update-database in powershell to commit the migrations to the database


//General notes
//----------------------------------------------------------------------------------------------------------------------------------------------------------------
//7. If a class has an "Id" property - entity framework will look for it and set it automatically as an identity in ssms


//8. context needs a class it is tracking to have an empty constructor (can be private)

//9. ReferentialAction. {Restrict/Cascade} cascade means if you delete the supermarket, all the catalogs within the supermarket will also be deleted,
// restrict means it will not allow you to delete the supermarket, you would have to delete all the catalogs first

//10. Migrations are classes to be tracked by EF which can be
// committed to the database and tables created using update-database in cmd
// whereas SaveChanges allows for the tables to be populated via code

//11. EF will first create an instance of the object using the empty constructor,
// then set the value of each of the properties 
namespace POS
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // will never fire OnConfiguring because you are not accessing any DbSet property or table
                var context = new PosContext();

                //var dbtest = new DbContext();

                //add a new instance of a supermarket and save it to the database
                var superMarket = new Supermarket("Great New World 2");
                context.Supermarkets.Add(superMarket);
                //var state = context.Entry(superMarket).State;
                context.SaveChanges();

                //Add a catalog and some products
                //var catalog = superMarket.AddCatalog("Spring Catalog");
                //catalog.AddProduct("Cola", 2.5m);
                //catalog.AddProduct("Chocolate", 5m);
                //catalog.AddProduct("Chips", 1.5m);
                //catalog.AddProduct("Apple", 0.55m);
                //catalog.AddProduct("Orange", 1.65m);
                //catalog.AddProduct("Miso", 7.5m);
                //catalog.AddProduct("Taco Shells", 6.5m);
                //catalog.AddProduct("Bread", 2.5m);
                //context.SaveChanges();

                // saying to EF that get all data of SuperMarket from sql server
                var superMarket = context.Supermarkets.ToList();

                var superMarket2 = context.Supermarkets.Include(s => s.Terminals).ToList();

                //what is this line doing ?
                var superMarket3 = context
                                    .Supermarkets
                                        .Include(s => s.Terminals)
                                        .Include(s => s.Catalogs)
                                            .ThenInclude(c=>c.Products)
                                        .FirstOrDefault(s => s.Id == 1);

                // .SaveChanges() saves the changes made only within this scope?
                // i.e add a new terminal
                // var t = superMarket.AddTerminal();
                //context.SaveChanges();

                //var catalog = superMarket.GetCatalog("Spring Catalog");
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
    }
}
